import React from 'react';

function Documents() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Documents</h1>
      <div className="bg-white rounded-lg shadow p-6">
        <p>Documents page content will go here.</p>
      </div>
    </div>
  );
}

export default Documents;