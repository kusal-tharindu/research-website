import React from 'react';

function Milestones() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Milestones</h1>
      <div className="space-y-4">
        <p>Project milestones will be displayed here.</p>
      </div>
    </div>
  );
}

export default Milestones;